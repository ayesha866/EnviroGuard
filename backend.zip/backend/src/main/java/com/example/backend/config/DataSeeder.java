package com.example.backend.config;
import com.example.backend.model.User;
import com.example.backend.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataSeeder {
    @Bean
    public CommandLineRunner seedSuperAdmin(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            // Check if a super admin already exists
            if (userRepository.findByUsername("superadmin").isEmpty()) {
                User superAdmin = new User();
                superAdmin.setUsername("superadmin");
                superAdmin.setPassword(passwordEncoder.encode("superadmin123"));
                superAdmin.setEmail("superadmin@company.com");// Change later in production
                superAdmin.setRole("ROLE_SUPER_ADMIN");
                superAdmin.setFactoryId(null); // 0 or null represents global access

                userRepository.save(superAdmin);
                System.out.println("✅ Default Super Admin created -> Username: superadmin | Password: superadmin123");
            }
        };
    }
}
